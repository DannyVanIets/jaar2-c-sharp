﻿using System;

namespace TentamenCS1920_tweede_kans
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
