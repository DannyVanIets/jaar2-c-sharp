﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opgave2
{
    public interface IProduct
    {
        int Gewicht { get; set; }
    }
}
