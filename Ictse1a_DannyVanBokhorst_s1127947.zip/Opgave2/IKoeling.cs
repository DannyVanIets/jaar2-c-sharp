﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opgave2
{
    public interface IKoeling
    {
        int Temperatuur { get; set; }
    }
}
