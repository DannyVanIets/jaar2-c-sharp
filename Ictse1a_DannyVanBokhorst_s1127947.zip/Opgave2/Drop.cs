﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opgave2
{
    class Drop : IProduct
    {
        public int Gewicht { get; set; }
    }
}
